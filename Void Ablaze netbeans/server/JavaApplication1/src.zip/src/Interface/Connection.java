/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;
import java.lang.*;
import java.io.*;
import java.net.*;
import Controllers.*;
import Tools.*;
import Data.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Magus
 */
public class Connection implements Runnable {
    ServerSocket skt;
    boolean active;
    public boolean player1;
    public int portNo;
    DataSerializer sr;
    public boolean isReserved = false;
    String reserverIP;
    ServerController ctrl;
    GameCalculator calc;
    DataInputStream in;
    DataOutputStream out;
    GameData data;
    private boolean shouldDie = false;
    
   
    //TODO: catchs
    
    Thread in_l = new Thread("input listener"){
        @Override
        public void run() {
            while(true){
                if( data == null)
                    System.out.println(" no data for connection, we have a problem");
                else{
                    try {
                       calc.addToInputQueue( sr.deSerialize( in.readUTF()));
                    } 
                    catch (IOException ex) {
                       Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                       in.reset();
                    } 
                    catch (IOException ex) {
                       Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
                    }  
                }
            }
        }
    };  
    
    public Connection( int localPort, ServerController sc){
        ctrl = sc;
        isReserved = false;
        try {
            skt = new ServerSocket(localPort);
            // 
            
        }
        catch(IOException e){
            //TODO
        }
        portNo = skt.getLocalPort();
    }
    
    public Connection( int localPort, ServerController sc, String reserverIP){
        ctrl = sc;
        this.reserverIP = reserverIP;
        isReserved = true;
        try {
            skt = new ServerSocket(localPort);
        }
        catch(IOException e){
            //TODO
        }
        int portNo = skt.getLocalPort();
    }
    
    private int requestReroute( String IP){
        // this requests creation of a new connection for a client,
        // later sends port no. of the created connection to that client
        return ctrl.generateAReservedConnection(IP);
    }
    
    public void postGameState( GameData data ){
        //only posts dynamic values
        try {
            //sends eveything upon game initialization
            out.writeUTF( "%" + player1 + "%" + sr.serialize(false, data) );
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void postGameInit( GameData data ){
        try {
            //sends eveything upon game initialization
            out.writeUTF( "%" + player1 + "%" + sr.serialize(false, data) );
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void inputData( String input){
        InputData id = new InputData();
        /*
        .
        .TODO
        .
        */
        calc.addToInputQueue(id);
    }
    
    public void addGameCalc( GameCalculator c){
        
        calc = c;
        data = calc.data;
    }
    
    private void endMe( GameCalculator c){
        //if connection drops
     
    }
    private void endMe( ServerController c){
        //if connection drops
    }
    
    public void endYourself(){
        shouldDie = true;
    }
    

    @Override
    public void run() {
        boolean run = false;
        while( run){
            try
            {
               Socket server = skt.accept();
               if(isReserved){
                   if( reserverIP.equals(server.getInetAddress().getHostAddress())){
                       server.close();
                       run = true;
                   }
                   else{
                       in = new DataInputStream(server.getInputStream());
                       out = new DataOutputStream(server.getOutputStream());
                       in_l.start();
                       run = false;
                   }
               }
               else{
                   int newPort = requestReroute(server.getInetAddress().getHostAddress());
                   String msg = "NEW:" + newPort;
                   server.close();
                   run = true;
               }
            }
            catch(IOException e)
            {
               e.printStackTrace();
            }
            if( shouldDie)
                Thread.currentThread().interrupt();
        }
    }
}
