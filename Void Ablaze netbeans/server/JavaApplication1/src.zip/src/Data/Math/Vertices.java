/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data.Math;

/**
 *
 * 
 */
public class Vertices {
    public int n;//vertex amount
    public Point[] vertices;
    
    public Vertices( int x ){
        n = x;
        vertices = new Point[n];
    } 
}
