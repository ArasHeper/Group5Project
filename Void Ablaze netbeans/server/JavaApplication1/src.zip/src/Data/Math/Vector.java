/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data.Math;

/**
 *
 * @author Magus
 */
public class Vector {
    public double x;
    public double y;
    public Vector( double a, double b){
        x = a;
        y = b;
    }
    public Vector(){
    }
}
