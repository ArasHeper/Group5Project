/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Data.Math.Veloc;
import Data.Math.Acc;

/**
 *
 * @author Magus
 */
public class Dynamic extends Physical {
   public boolean isDynamic =  true;
   public double mass; 
   public Acc acc;
   public Veloc veloc;
}


