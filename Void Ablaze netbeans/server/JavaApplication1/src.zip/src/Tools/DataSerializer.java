/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;
import Data.*;
/**
 *
 * @author Magus
 */
public class DataSerializer {
    public String serialize( boolean init, GameData data){
        // BS:loc.X,loc.y;dir.X,dir.Y-loc.X,loc.Y;dir.x,dir.Y
        // ===> BS: battleship1-battleship2
        //BS:(cont)|CP:(cont)
        // > CP:(cont);
        // (cont) = +loc.X,loc.Y;dir.X,dir.Y+(etc. for other cannonPs)-(2nd players cannon Ps) 
        String ser = "";
        ser = ser + "BS:" + String.valueOf( data.p1.loc.x) + "," + String.valueOf( data.p1.loc.y)
                + ";" + String.valueOf( data.p1.dir.x) + "," + String.valueOf( data.p1.dir.y);
        ser = ser + "-" + String.valueOf( data.p2.loc.x) + "," + String.valueOf( data.p2.loc.y)
                + ";" + String.valueOf( data.p2.dir.x) + "," + String.valueOf( data.p2.dir.y);
        ser = ser + "|CP:";
        for( CannonProjectile item: data.cans1 ){
            ser = ser + "+" + String.valueOf(item.loc.x) + "," + String.valueOf(item.loc.y)
                    + ";" + String.valueOf(item.dir.x) + "," + String.valueOf(item.dir.y);
        }
        ser = ser + "-";
        for( CannonProjectile item: data.cans2 ){
            ser = ser + "+" + String.valueOf(item.loc.x) + "," + String.valueOf(item.loc.y)
                    + ";" + String.valueOf(item.dir.x) + "," + String.valueOf(item.dir.y);
        }
        //TODO: add others if time allows  
        return ser + "/n";
    }
    public InputData deSerialize( String data){
        return new InputData(); //TODO
    }
    
}
