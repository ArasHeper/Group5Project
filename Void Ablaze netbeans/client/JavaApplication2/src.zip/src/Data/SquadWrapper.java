/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author Magus
 */
public class SquadWrapper {
    public boolean type;
    public double x;
    public double y;
    public int size;
    public int ID;
    public int state;
}
